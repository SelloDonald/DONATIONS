<?php
//php code to search data in the database

if(isset($_POST['search'])){
	$Eword = $_POST['Eword'];
	//$con = mysqli_connect("sql203.unaux.com","unaux_23693641","ih64eenhho","unaux_23693641_sello");
	$con = mysqli_connect("localhost","root","","test");
	$query = "SELECT `Emeaning`, `Sword`, `Smeaning` FROM `words` WHERE `Eword`= '$Eword'";
	
	if(!$con){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$result = mysqli_query($con,$query);

	if(mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$Emeaning = $row['Emeaning'];
			$Sword = $row['Sword'];
			$Smeaning = $row['Smeaning'];
		}
	}
	
	//mysqli_free_result($result);
	mysqli_close($con);
	

}else{
		$Emeaning = "";
		$Sword = "";
		$Smeaning = "";
}


?>