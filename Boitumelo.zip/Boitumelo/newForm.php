<!DOCTYPE html>
<html>
<?php
    include 'menus.inc';
?>

<div class="col-md-11" style='margin-left: 65px'>


	<div class="navbar navbar-default">
	             <ul class="nav navbar-nav navbar-left">
                    <li class="nav"><h2> For Reference, Please Provide Your Personal Details</h2></li>
					
					
     
                </ul>
	</div>
	<hr/>
	<div class="container">
	<div class="row">

        <div class = "col-md-8" align='left'>
	<div class="well">
	<p class="lead">

<form action = "newForm2.php" method = "POST">

    <div class="form-group">
		<label for="FullNames"> Full Names</label>
		<input class="form-control" type = "text" id="FullNames" name = "FullNames" placeholder="Full Names" required> 
		
		<label for="Surname"> Family Name</label>
		<input class="form-control" type = "text" id="Surname" name = "Surname" placeholder="Surname" required>
		
		<label for="Email"> Email Address</label>
		<input class="form-control" type = "email" id="Email" name = "Email" placeholder="e.g donation@hope.co.za" required>
		
		<label for="amount"> Any Amount You Wish to Donate</label>
		<input class="form-control" type = "number" id="amount" name = "amount" placeholder="R " required>
		
		<label for="other">Any other things to donate</label>
		<input class="form-control" type = "email" id="other" name = "other" placeholder="E.g books, Laptop, tablet etc" >
		</div>
		<br/>
<br/>
<hr/>
<button input type = "submit" name = "Submit" class="btn btn-success">Submit Your Donation</button><br/>



</div>
</div>

<div class = "col-md-4" align='left'>
	<div class="well">
	<p class="lead">
	
<h3>Have you donated before or you want to confirm your name on our database? Please Provide Your Email Address</h3>

<form action = "newForm2.php" method = "POST">

    <div class="form-group">
	<label for="Email"> Enter Your Email Address To Review Your Donation</label>
		<input class="form-control" type = "text" id="Email" name = "Email" placeholder="Email Address" required>
		<label for="Names"> Full Names</label>
		<input class="form-control" type = "text" id="Names" name = "Names"> 
		<label for="Amount"> Amount You Donated </label>
		<input class="form-control" type = "text" id="Amount" name = "Amount" placeholder="R"> 
		<label for="other"> Any other donations </label>
		<input class="form-control" type = "text" id="other" name = "other">

		</div>
<button input type = "submit" name = "Search" class="btn btn-success">Search</button><br/>
</form>

		

</div>

</div>
</div>

</div>

</div>
</div>
</form>
</body>
</html>