<!DOCTYPE html>
<html>
<?php include 'menus.inc'; ?>


<body>

<?php
include_once 'donationsdb_connection.php';
if(isset($_POST['Submit']))
{	 
	 $first_name = $_POST['FullNames'];
	 $surname = $_POST['Surname'];
	 $email = $_POST['Email'];
	 $amount = $_POST['amount'];
	 $other = $_POST['other'];
	 
	 $sql = "INSERT INTO Donations (Email, FullNames, Surname, amount, other)
	 VALUES ('$email','$first_name','$surname', '$amount','$other')";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

if(isset($_POST['Search'])){
	$Email1 = $_POST['Email1'];
	$query = "SELECT `Email`, `FullNames`, `Surname`,amount,`other` FROM donations WHERE `Email`= '$Email1'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$result = mysqli_query($conn,$query);

	if(mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$FullNames1 = $row['FullNames'];
			$Surname1 = $row['Surname'];
			$amount1 = $row['amount'];
			$other1 = $row['other'];
			
			
		}
			
	}
	
	//mysqli_free_result($result);
	mysqli_close($conn);
}else{
			$FullNames1 = " ";
			$Surname1 = " ";
			$amount1 = " ";
			$other1 = " ";
			$Email1 = " ";
	}


?>



<div class="col-md-11" style='margin-left: 65px' align='center'>


	<div  class="navbar navbar-default">
	             <ul class="nav navbar-nav navbar-left">
                    <li class="nav"><h2>&nbsp &nbsp For Reference, Please Provide Your Personal Details</h2></li>
					
					
     
                </ul>
	</div>
	
	<hr/>
	<div class="container">
	<div class="row">

        <div class = "col-md-8" align='left'>
	<div class="well">
	<p class="lead">

<form action = "sucess.php" method = "POST">

    <div class="form-group">

		<label for="FullNames"> Full Names</label>
		<input class="form-control" type = "text" id="FullNames" name = "FullNames" placeholder="Full Names" required> 
		
		<label for="Surname"> Family Name</label>
		<input class="form-control" type = "text" id="Surname" name = "Surname" placeholder="Surname" required>
		
		<label for="Email"> Email Address</label>
		<input class="form-control" type = "email" id="Email" name = "Email" placeholder="e.g donation@hope.co.za" required>
		
		<label for="amount"> Any Amount You Wish to Donate</label>
		<input class="form-control" type = "number" id="amount" name = "amount" placeholder="Put 0(zero) amount if you are not donating with cash" required>
		
		<label for="other">Any other things to donate</label>
		<input class="form-control" type = "text" id="other" name = "other" placeholder="E.g books, Laptop, tablet etc" >
		</div>
		<br/>
<br/>
<hr/>
<button input type = "submit" name = "Submit" class="btn btn-success">Submit Your Donation</button><br/>



</div>
</div>
</form>
<div class = "col-md-4" align='left'>
	<div class="well">
	<p class="lead">
	
<h3>Have you donated before or you want to confirm your name on our database? Please Provide Your Email Address</h3>

<form action = "index.php" method = "POST">

    <div class="form-group">
	<label for="Email"> Enter Your Email Address To Review Your Donation</label>
		<input class="form-control" type = "text" name = "Email1" placeholder="Email Address" required>
		<label for="Names"> Full Names</label>
		<input class="form-control" type = "text"  value = "<?php echo $FullNames1 ." " .$Surname1; ?>"> 
		<label for="Amount"> Amount You Donated </label>
		<input class="form-control" type = "text" value = "<?php echo $amount1; ?>" placeholder="R"> 
		<label for="other"> Any other donations </label>
		<input class="form-control" type = "text"  value = "<?php echo $other1; ?>">

		</div>
<button input type = "submit" name = "Search" class="btn btn-success">Search</button><br/>

</form>

		

</div>


</div>
</div>

</div>
<br/>
<br/>
<br/>
<br/>

<p align="center"><iframe src="Task1.txt" height="400" width="1200" style="background: #f4f4dd;"></p>
</div>
</div>
</form>


</body>
</html>