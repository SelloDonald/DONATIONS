<!DOCTYPE html>
<html>
<?php include 'menus.inc'; ?>

<body>
<?php

include_once 'donationsdb_connection.php';
if(isset($_POST['Submit']))
{	 
	 $first_name = $_POST['FullNames'];
	 $surname = $_POST['Surname'];
	 $email = $_POST['Email'];
	 $amount = $_POST['amount'];
	 $other = $_POST['other'];
	 
	 $sql = "INSERT INTO Donations (Email, FullNames, Surname, amount, other)
	 VALUES ('$email','$first_name','$surname', '$amount','$other')";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

if(isset($_POST['Search'])){
	$Email1 = $_POST['Email1'];
	$query = "SELECT `Email`, `FullNames`, `Surname`,amount,`other` FROM donations WHERE `Email`= '$Email1'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$result = mysqli_query($conn,$query);

	if(mysqli_num_rows($result)){
		while($row = mysqli_fetch_assoc($result)){
			$FullNames1 = $row['FullNames'];
			$Surname1 = $row['Surname'];
			$amount1 = $row['amount'];
			$other1 = $row['other'];
			
			
		}
			
	}
	
	//mysqli_free_result($result);
	mysqli_close($conn);
}else{
			$FullNames1 = " ";
			$Surname1 = " ";
			$amount1 = " ";
			$other1 = " ";
			$Email1 = " ";
	}


?>
<div class="col-md-11" style='margin-left: 30px'>

	<hr/>
	<div class="container">
	<div class="row">

    <div class = "col-md-11" align='center' style="color: #b3ffb3;">
	<div class="well">
	<p class="lead">
	
	<p align="center"><h2>Thank you for your Donation!!</h2>
	<br/>
	<h4>We will send you an email with all the information and steps from here</h4>
<form action = "index.php" method = "POST">
<button input type = "Ok" name = "OK" class="btn btn-success">OK</button><br/>
</form>



</body>


</html>