<!DOCTYPE html>
<html>
<?php include 'menus.inc'; ?>

<body>
<?php
include_once 'donationsdb_connection.php';
if(isset($_POST['Submit']))
{	 
	 $first_name = $_POST['FullNames'];
	 $surname = $_POST['Surname'];
	 $email = $_POST['Email'];
	 
	  if(empty($first_name)){
                $sql = "UPDATE Donations SET Surname ='$surname' WHERE Email = '$email'";
            } else if (empty($surname)){
                $sql = "UPDATE Donations SET FullNames = '$first_name' WHERE Email = '$email'";
				}else if(!empty($first_name) || !empty($surname) ){
					$sql = "UPDATE Donations SET FullNames = '$first_name', Surname ='$surname' WHERE Email = '$email'";
				}
				
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

if(isset($_POST['Remove']))
{	 
	 $email1 = $_POST['Email1'];
	 $sql = "DELETE FROM Donations WHERE Email ='$email1'";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>

<div class="col-md-11" style='margin-left: 30px'>

	<hr/>
	<div class="container">
	<div class="row">

    <div class = "col-md-11" align='center' style="color: #b3ffb3;">
	<div class="well">
	<p class="lead">
	
	<p align="center"><h2>Your details has been updated Sucessfully</h2>

<form action = "index.php" method = "POST">
<button input type = "Ok" name = "OK" class="btn btn-success">OK</button><br/>
</form>



</body>


</html>