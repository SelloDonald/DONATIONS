<!DOCTYPE html>
<html>
<?php include 'menus.inc'; ?>

<body>

<?php
include_once 'donationsdb_connection.php';
if(isset($_POST['Submit']))
{	 
	 $first_name = $_POST['FullNames'];
	 $surname = $_POST['Surname'];
	 $email = $_POST['Email'];
	 
	  if(empty($first_name)){
                $sql = "UPDATE Donations SET Surname ='$surname' WHERE Email = '$email'";
            } else if (empty($surname)){
                $sql = "UPDATE Donations SET FullNames = '$first_name' WHERE Email = '$email'";
				}else if(!empty($first_name) || !empty($surname) ){
					$sql = "UPDATE Donations SET FullNames = '$first_name', Surname ='$surname' WHERE Email = '$email'";
				}
				
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

if(isset($_POST['Remove']))
{	 
	 $email1 = $_POST['Email1'];
	 $sql = "DELETE FROM Donations WHERE Email ='$email1'";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>

<div class="col-md-11" style='margin-left: 30px'>

	<hr/>
	<div class="container">
	<div class="row">

        <div class = "col-md-6" align='left'>
	<div class="well">
	<p class="lead">
<h3 >Update Personal details here</h3>

<form action = "updated.php" method = "POST">

    <div class="form-group">
		<label for="FullNames"> Full Names</label>
		<input class="form-control" type = "text" id="FullNames" name = "FullNames" placeholder="Full Names"> 
		
		<label for="Surname"> Family Name</label>
		<input class="form-control" type = "text" id="Surname" name = "Surname" placeholder="Surname">
		
		<label for="Email"> Email Address</label>
		<input class="form-control" type = "email" id="Email" name = "Email" placeholder="e.g donation@hope.co.za" required>
		

		

		</div>
		<br/>
<br/>
<hr/>
<button input type = "submit" name = "Submit" class="btn btn-success">Update Details</button><br/>



</div>
</div>
</form>

<div class = "col-md-6" align='left'>
	<div class="well">
	<p class="lead">
	
<h3 >Already Donated and want to keep your donation anonymous or delete you record from our database? <b style="color: #f42525;">You can remove your yourself by providing your email address</b></h3>

<form action = "deleted.php" method = "POST">

    <div class="form-group">
	<label for="Email"> Enter Your Email Address To Review Your Donation</label>
		<input class="form-control" type = "text" id="Email" name = "Email1" placeholder="Email Address" required>


		</div>
<button input type = "remove" name = "Remove" class="btn btn-success">Remove</button><br/>
</form>

		

</div>

</div>
</div>

</div>
<br/>
<br/>
<br/>
<br/>

<p align="center"><iframe src="Task2.txt" height="400" width="1200" style="background: #f4f4dd;"></p></div>
</div>


</body>


</html>