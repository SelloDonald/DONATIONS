<?php include 'menus.inc'; ?>
<!DOCTYPE html>
<html>
<body>

<?php  
include_once 'connection.php';
if(isset($_POST['Search'])){
	$Email1 = $_POST['email1'];
	$query = "SELECT `Email`, `FullNames`, `Surname`,amount,`other` FROM donations WHERE `Email`= '$Email1'";
	
	if(!$conn){
		die("Connection Failed: " . mysqli_connect_error());
	}
	
	$result = mysqli_query($conn,$query);

	if(mysqli_num_rows($result)){
		while($row = mysqli_fetch_assoc($result)){
			$FullNames1 = $row['FullNames'];
			$Surname1 = $row['Surname'];
			$amount1 = $row['amount'];
				
			
		}
			
	}
	
	//mysqli_free_result($result);
	mysqli_close($conn);
}else{
			$FullNames1 = " ";
			$Surname1 = " ";
			$amount1 = " ";
			$Email1 = " ";
	}



if(isset($_POST['Update']))
{	 
	 $first_name = $_POST['FullNames2'];
	 $surname = $_POST['Surname2'];
	 $email = $_POST['Email2'];
	 
	  if(empty($first_name)){
                $sql = "UPDATE Donations SET Surname ='$surname' WHERE Email = '$email'";
            } else if (empty($surname)){
                $sql = "UPDATE Donations SET FullNames = '$first_name' WHERE Email = '$email'";
				}else if(!empty($first_name) || !empty($surname) ){
					$sql = "UPDATE Donations SET FullNames = '$first_name', Surname ='$surname' WHERE Email = '$email'";
				}
				
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

if(isset($_POST['Remove']))
{	 
	 $email1 = $_POST['Email1'];
	 $sql = "DELETE FROM Donations WHERE Email ='$email1'";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}



if(isset($_POST['Remove']))
{	 
	 $email3 = $_POST['Email3'];
	 $sql = "DELETE FROM Donations WHERE Email ='$email3'";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>





<div class="col-md-10" style='margin-left: 65px'>
<hr/>
<h2>Review your Donation here</h2>
	 <div class="well">
      <p class="lead">
        <div align='left'>

<form action = "form2.php" method = "POST">

    <div class="form-group">
	<label for="word"> Search with your First name:</label>
		<input class="form-control" type = "email" id="word" name = "email1" " placeholder="e.g someone@gmail.com">
	<label for="word"> First Name:</label>
		<input class="form-control" type = "text" id="word" name = "FullNames" value ="<?php echo $FullNames1 ?>" placeholder="Enter your first name"> 
		
		<label for="word"> Last Name:</label>
		<input class="form-control" type = "text" id="word" name = "Surname" value="<?php echo $Surname1 ?>" placeholder="Enter your last name">
		
		<label for="word"> Amount in Rands R:</label>
		<input class="form-control" type = "number" id="word" value="<?php echo $amount1 ?>" name = "amount" placeholder="R 1000">
		</div>
<button input type = "submit" name = "Search" class="btn btn-success">Search</button><br/>
</form>
</div>


<div class="col-md-13" style='margin-right: 65px'>
<hr/>
<h2>Update your Donation Details here:</h2>
<br/>

<form action = "form2.php" method = "POST">

    <div class="form-group">
	<label for="word">Provide the Field you Want to Update</label>
		<input class="form-control" type = "email" id="word" name = "Email2" placeholder="e.g someone@gmail.com"> 
	    <label for="word"> First Name:</label>
		<input class="form-control" type = "text" id="word" name = "FullNames2" placeholder="Enter your first name">
		<label for="word"> Last Name:</label>
		<input class="form-control" type = "text" id="word" name = "Surname2" placeholder="Enter your last name">
		
		
		</div>
<button input type = "submit" name = "Update" class="btn btn-success">Update</button><br/>



</form>
</div>

<div class="col-md-4" style='margin-right: 85px'>
<hr/>
<h4>Want To Remove Your Name from the list of Donors ?</h4>
<br/>

<form action = "form2.php" method = "POST">

    <div class="form-group">
<label for="word"> Email Address:</label>
<input class="form-control" type = "email" id="word" name = "Email3" placeholder="e.g someone@gmail.com">
<button input type = "submit" name = "Remove" class="btn btn-success">Remover</button><br/>



</form>
</div>

</body>
</html>