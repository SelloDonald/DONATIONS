<!DOCTYPE html>
<html>
<?php include 'menus.inc'; ?>

<body>

<?php

include_once 'connection.php';
if(isset($_POST['Donate']))
{	 
	 $first_name = $_POST['name'];
	 $surname = $_POST['lastname'];
	 $email = $_POST['email'];
	 $amount = $_POST['cash'];
	 $other = $_POST['another'];
	 
	 $sql = "INSERT INTO Donations (Email, FullNames, Surname, amount, other)
	 VALUES ('$email','$first_name','$surname', '$amount','$other')";
	 
	 
	 if (mysqli_query($conn, $sql)) {
		echo " ";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>


<div class="col-md-11" style='margin-left: 65px'>
<hr/>
<h2>Donors Personal Details:</h2>
	 <div class="well">
      <p class="lead">
        <div align='left'>


<form action = "index.php" method = "POST">

    <div class="form-group">
	<label for="word"> First Name:</label>
		<input class="form-control" type = "text" id="word" name = "name" placeholder="Enter your first name"> 
		
		<label for="word"> Last Name:</label>
		<input class="form-control" type = "text" id="word" name = "lastname" placeholder="Enter your last name">
		
		<label for="word"> Email Address:</label>
		<input class="form-control" type = "email" id="word" name = "email" placeholder="e.g someone@gmail.com">
		
		<label for="word"> Amount in Rands R:</label>
		<input class="form-control" type = "number" id="word" name = "cash" placeholder="R 1000">
		
		<label for="word"> Other Forms of Donations:</label>
		<input class="form-control" type = "email" id="word" name = "another" placeholder="e.g laptops, used books etc">
		</div>
<button input type = "submit" name = "Donate" class="btn btn-success">Donate</button><br/>
<hr>


</form>
</body>
</html>