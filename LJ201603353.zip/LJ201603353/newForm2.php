<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale = 1.0" />
    <title>Assesment</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="bootstrap/css/black2-bootstrap.min.css">
    <link href="css.css" rel="stylesheet">

<body>
<div class="col-md-10" style='margin-left: 65px'>
<hr/>
<h2>Review your Donation here &#128522;</h2>
	 <div class="well">
      <p class="lead">
        <div align='left'>
	<div class="navbar navbar-default">
	             <ul class="nav navbar-nav navbar-left">
                    <li class="nav">Donations form</li>
                </ul>
	</div>

<form action = "newForm2.php" method = "POST">

    <div class="form-group">
	<label for="word"> Search with your email address:</label>
		<input class="form-control" type = "text" id="word" name = "Eword" placeholder="Enter your first name"> 
		</div>
<button input type = "submit" name = "Search" class="btn btn-success">Search</button><br/>
</form>
</div>


<div class="col-md-13" style='margin-right: 65px'>
<hr/>
<h2>Update your Donation Details here:</h2>
<br/>

<form action = "newForm2.php" method = "POST">

    <div class="form-group">
	<label for="word">Provide the Field you Want to Update</label>
		<input class="form-control" type = "text" id="word" name = "Eword" placeholder="i.e First Name, Last Name or Amount etc"> 
		</div>
<button input type = "submit" name = "Update" class="btn btn-success">Update</button><br/>



</form>
</div>

<div class="col-md-4" style='margin-right: 85px'>
<hr/>
<h4>Want To Remove Your Name from the list of Donors ?</h4>
<br/>

<form action = "newForm2.php" method = "POST">

    <div class="form-group">
	<label for="word">Provide your email address:</label>
		<input class="form-control" type = "text" id="word" name = "Eword" placeholder="You can remove your name here"> 
		</div>
<button input type = "submit" name = "Update" class="btn btn-success">Remover</button><br/>



</form>
</div>

</body>
</html>