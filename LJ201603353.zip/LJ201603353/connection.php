<?php
$conn=mysqli_connect('localhost','id16791681_lebogang','2[8b!VvBk<flj-A4','id16791681_lebogan');
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
	
?>